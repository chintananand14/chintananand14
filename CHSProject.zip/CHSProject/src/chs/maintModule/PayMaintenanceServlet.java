package chs.maintModule;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class PayMaintenanceServlet
 */
@WebServlet("/PayMaintenanceServlet")
public class PayMaintenanceServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PayMaintenanceServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
			System.out.println("pay maintenance servlet");
		
		
		String errMessage=null;
		String  succMessage=null;
		//String pendingAmount=request.getParameter("pendingAmount");
		String personNameId=request.getParameter("personNameId");
		String address=request.getParameter("address");
		String wing=address.substring(0,1);
		System.out.println("wing ::"+wing);
		String flatNum=address.substring(1);
		System.out.println("flatNumb ::"+flatNum);
		//String nextduedate=request.getParameter("nextduedate");
		String fromMonth=request.getParameter("fromMonth");
		String fromYear=request.getParameter("fromYear");
		String toMonth=request.getParameter("toMonth");
		String toYear=request.getParameter("toYear");
		String cheque=request.getParameter("cheque");
		String cash=request.getParameter("cash");
		String paymode=cheque !=null ?cheque :cash;
		String chequeNumber=request.getParameter("chequeNumber");
		String chequeAmount=request.getParameter("chequeAmount");
		String chequeBankName=request.getParameter("chequeBankName");
		String chequeBankNumber=request.getParameter("chequeBankNumber");
		String cashAmount=request.getParameter("cashAmount");
		//String chequeNumber=request.getParameter("chequeNumber");
		String maintGivenTo=request.getParameter("maintGivenTo");
		String amount=cashAmount!=null?cashAmount :chequeAmount;
		if(amount=="") {
			amount="0";
		}
		/*
		int amountInt=Integer.parseInt(amount);
		int pendingFromDB=Integer.parseInt(pendingAmount);
		int RemainingAmount=pendingFromDB-amountInt;
		int pendingAmountCal=0;
		if(RemainingAmount <=0) {
			RemainingAmount=pendingAmountCal;
		}
		*/
		
		//System.out.println("pendingAmount :"+pendingAmount);
		System.out.println("personNameId "+personNameId);
		System.out.println("address :"+address);
		//System.out.println("nextduedate :"+nextduedate);
		System.out.println("fromMonth "+fromMonth);
		System.out.println("fromYear "+fromYear);
		System.out.println("toMonth :"+toMonth);
		System.out.println("toYear :"+toYear);
		System.out.println("cheque :"+cheque);
		System.out.println("cash :"+cash);
		System.out.println("chequeNumber :"+chequeNumber);
		System.out.println("chequeAmount :"+chequeAmount);
		System.out.println("chequeBankName :"+chequeBankName);
		System.out.println("chequeBankNumber :"+chequeBankNumber);
		System.out.println("cashAmount :"+cashAmount);
		System.out.println("maintGivenTo :"+maintGivenTo);
	
		String[] paymentMonthArr=null;
		String insertMaintPaySql=null;
		String paymentMonthYear=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");  
			System.out.println("mysql driver is loaded");
			Connection con=DriverManager.getConnection(  
			"jdbc:mysql://localhost:3306/cshsdb","root","root");  
			System.out.println("connection established");
				
		//String fromMonthYear=fromMonth+"-"+fromYear;
		//String toMonthYear=toMonth+"-"+toYear;
		
			System.out.println("fromMonth ->"+fromMonth);
			System.out.println("toMonth ->"+toMonth);
			
			String paymentMonthYearString= calculatePaymentMonthString(fromMonth,fromYear,toMonth,toYear);
			 paymentMonthArr= paymentMonthYearString.split(",");
			System.out.println("paymentMonthArr .length "+paymentMonthArr.length);
			for(int i=0;i<paymentMonthArr.length-1;i++) {
				 insertMaintPaySql="INSERT INTO SocMaintenancepay\r\n" + 
							"(personnameId,\r\n" + 
							"Wing,\r\n" + 
							"FlatNumber,\r\n" + 
							"paymentMode,\r\n" + 
							"chequeNumber,\r\n" + 
							"chequeAmount,\r\n" + 
							"chequeAccountNumber,\r\n" + 
							"chequeBank,\r\n" + 
							"cashAmount,\r\n" + 
							"paymentMonthYear,\r\n" + 
							"MaintGivenTo,lastupdatedt)\r\n" + 
							"VALUES\r\n" + 
							"('"+personNameId.trim()+"','"+wing+"','"+flatNum+"','"+paymode+"','"+chequeNumber+"','"+chequeAmount+"','"+chequeBankNumber+"','"+chequeBankName+"','"+cashAmount+"','"+paymentMonthArr[i]+"','"+maintGivenTo+"',now())";
					
				 System.out.println("insertMaintPaySql loop -->"+insertMaintPaySql);
				 String checkMaintRecord="select personnameId from SocMaintenancepay where wing='"+wing+"' and FlatNumber='"+flatNum+"' and paymentMonthYear='"+paymentMonthArr[i]+"' ";
				 Statement stmt=con.createStatement();  
					System.out.println("checkMaintRecord query "+checkMaintRecord);
					ResultSet checkMainRecordRS=stmt.executeQuery(checkMaintRecord);
					
					if(checkMainRecordRS.next()==false) {
						System.out.println("OK to insert record");
						stmt.execute(insertMaintPaySql);
						
					succMessage="Record inserted Successfully for "+paymentMonthArr[i]+","+succMessage;
					}else {
						//monthYear=monthyearTemp+","+monthYear;
						 errMessage="Record is not inserted as maintenance is paid for month   "+paymentMonthArr[i]+" already"+","+errMessage;
						System.out.println("FromDate or ToDate mismatch with DB. Please check to view report");
					}
					
			
		}
		}catch(SQLException e) {
			 errMessage="Record is not inserted SQL Exception ";
			response.sendRedirect("addSocietyPayment.jsp?succMessage="+errMessage );
			e.printStackTrace();
			
		}catch(Exception e1) {
			e1.printStackTrace();
		}
		
		System.out.println("errMessage ::"+errMessage);
		System.out.println("succMessage ::"+succMessage);
		if(errMessage!=null) {
			response.sendRedirect( "MaintenanceHome.jsp?errorMessage="+errMessage );
		}else {
			response.sendRedirect( "MaintenanceHome.jsp?succMessage="+succMessage );
			
		}
		
		//System.out.println("insertMaintPaySql -->"+insertMaintPaySql);
	}

	private String calculatePaymentMonthString(
			String fromMonth, String fromYear, String toMonth, String toYear) {
		// TODO Auto-generated method stub
		String intFromMonth=null;
		String  inttoMonth=null;
		System.out.println("fromMonth calculatePaymentMonthString "+fromMonth);
		System.out.println("toMonth calculatePaymentMonthString "+toMonth);
		//String fromMonth="January";
		//String toMonth="December";
		//String fromYear="2017";
		//String toYear="2018";
		if(fromMonth.equalsIgnoreCase("January")) {
			intFromMonth="01";
		}else if(fromMonth.equalsIgnoreCase("February")) {
			intFromMonth="02";
		}else if(fromMonth.equalsIgnoreCase("March")) {
			intFromMonth="03";
		}
		else if(fromMonth.equalsIgnoreCase("April")) {
			intFromMonth="04";
		}
		else if(fromMonth.equalsIgnoreCase("May")) {
			intFromMonth="05";
		}
		else if(fromMonth.equalsIgnoreCase("June")) {
			intFromMonth="06";
		}
		else if(fromMonth.equalsIgnoreCase("July")) {
			intFromMonth="07";
		}
		else if(fromMonth.equalsIgnoreCase("August")) {
			intFromMonth="08";
		}
		else if(fromMonth.equalsIgnoreCase("September")) {
			intFromMonth="09";
		}
		else if(fromMonth.equalsIgnoreCase("October")) {
			intFromMonth="10";
		}
		else if(fromMonth.equalsIgnoreCase("November")) {
			intFromMonth="11";
		}
		else if(fromMonth.equalsIgnoreCase("December")) {
			intFromMonth="12";
		}
		
		
		if( toMonth.equalsIgnoreCase("January")) {
			inttoMonth="01";
		}else if(toMonth.equalsIgnoreCase("February")) {
			inttoMonth="02";
			
		}else if(toMonth.equalsIgnoreCase("March")) {
			inttoMonth="03";
			
		}else if(toMonth.equalsIgnoreCase("April")) {
			inttoMonth="04";
			
		}else if(toMonth.equalsIgnoreCase("May")) {
			inttoMonth="05";
			
		}else if(toMonth.equalsIgnoreCase("June")) {
			inttoMonth="06";
			
		}else if(toMonth.equalsIgnoreCase("July")) {
			inttoMonth="07";
			
		}else if(toMonth.equalsIgnoreCase("August")) {
			inttoMonth="08";
			
		}else if(toMonth.equalsIgnoreCase("September")) {
			inttoMonth="09";
			
		}else if(toMonth.equalsIgnoreCase("October")) {
			inttoMonth="10";
			
		}else if(toMonth.equalsIgnoreCase("November")) {
			inttoMonth="11";
			
		}else if(toMonth.equalsIgnoreCase("December")) {
			inttoMonth="12";
			
		}
		
		
		System.out.println("fromMonth ::"+fromMonth);
		System.out.println("toMonth ::"+toMonth);
		String date1="01".concat("/").concat(intFromMonth).concat("/").concat(fromYear);
		String date2="01".concat("/").concat(inttoMonth).concat("/").concat(toYear);
		//String date1 = "20/12/2011";
	    //String date2 = "22/08/2012";
        String monthYear=null;
	    DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/uuuu", Locale.ROOT);
	   // DateTimeFormatter monthFormatter = DateTimeFormatter.ofPattern("MMM/uuuu", Locale.ROOT);
	    DateTimeFormatter monthFormatter = DateTimeFormatter.ofPattern("MMM-uuuu", Locale.ROOT);
	    YearMonth endMonth = YearMonth.parse(date2, dateFormatter);
	    for (YearMonth month = YearMonth.parse(date1, dateFormatter);
	            ! month.isAfter(endMonth);
	            month = month.plusMonths(1)) {
	    	String monthyearTemp=month.format(monthFormatter);
	        System.out.println(month.format(monthFormatter));
	        monthYear=monthyearTemp+","+monthYear;
	    }
		
		System.out.println("monthYear -->"+monthYear);
		return monthYear;
	}

	
}
	
	
	


