package chs.maintModule;

import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Locale;

public class MonthCalc {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*Date fromDate= new Date("1/4/2016");
		Date toDate = new Date("31/12/2016");

		int j=0;
		while(fromDate.before(toDate)){
		    j=j+1;
		    fromDate.setMonth(j);
		    System.out.println(fromDate);
		}
*/		
		
		    String date1 = "20/12/2011";
		    String date2 = "22/08/2012";

		    DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/uuuu", Locale.ROOT);
		   // DateTimeFormatter monthFormatter = DateTimeFormatter.ofPattern("MMM/uuuu", Locale.ROOT);
		    DateTimeFormatter monthFormatter = DateTimeFormatter.ofPattern("MMM-uuuu", Locale.ROOT);
		    YearMonth endMonth = YearMonth.parse(date2, dateFormatter);
		    for (YearMonth month = YearMonth.parse(date1, dateFormatter);
		            ! month.isAfter(endMonth);
		            month = month.plusMonths(1)) {
		        System.out.println(month.format(monthFormatter));
		    }
			}

}
