package chs.maintModule;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MaintDetails
 */
@WebServlet("/MaintDetails")
public class MaintDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MaintDetails() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		String wing=request.getParameter("wing");
		String flatNum=request.getParameter("flatNum");
		String fromDate=request.getParameter("fromDate");
		String toDate=request.getParameter("toDate");
		String addPaymentButton=request.getParameter("addPaymentButton");
		String searchButton=request.getParameter("SearchButton");
		System.out.println("addPaymentButton ::"+addPaymentButton);
		System.out.println("searchButton ::"+searchButton);
		MaintenanceBean maintBean= new MaintenanceBean();
		System.out.println("Wing ::"+wing+"flatNum:: "+flatNum+" fromDate ::  "+fromDate+" toDate ::"+toDate);
		String errorMessage=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection(  
					"jdbc:mysql://localhost:3306/cshsdb","root","root");  
					System.out.println("connection established");
					//here sonoo is database name, root is username and password  
					Statement stmt=con.createStatement();  
					String flatName=wing.concat(flatNum);
					String personNameId=null;
					String fullName=null;
					String firstName=null;
					String lastName=null;
					String address=null;
					
					
			        
					
					String getPersonString="select FirstName ,LastName,PersonNameId,flatNametpcd,pendingAmount,DATE_FORMAT(nextDuedate, '%d/%m/%Y') nextDuedate,TIMESTAMPDIFF(MONTH, nextDuedate,current_date()) as overduemonth from permaintenanceview where flatnametpcd='"+flatName+"' ";
					ResultSet getPersonRS=stmt.executeQuery(getPersonString);
					
					if(getPersonRS.next()==false) {
						System.out.println("Primary Owner of this flat is not added .");
						errorMessage="Flat Primary Owner is not added for Flat Number"+flatName;
					}else {
						do { 
							int pendingAmountS=0;
							personNameId=getPersonRS.getString("PersonNameId");
							firstName=getPersonRS.getString("FirstName");
							lastName=getPersonRS.getString("LastName");
							fullName=firstName.concat(" ").concat(lastName);
							String overduemonth=getPersonRS.getString("overduemonth");
							if(overduemonth !=null && Integer.parseInt(overduemonth)>0) {
								pendingAmountS=Integer.parseInt(overduemonth)*600;
								maintBean.setPendingAmount(String.valueOf(pendingAmountS));
							}else {
								overduemonth="0";
								pendingAmountS=Integer.parseInt(overduemonth)*600;
								maintBean.setPendingAmount(String.valueOf(pendingAmountS));
							}
							address=getPersonRS.getString("flatNametpcd");
							maintBean.setFullName(fullName);
							maintBean.setFirstName(firstName);
							maintBean.setLastName(lastName);
							maintBean.setPersonNameId(personNameId);
							maintBean.setFlatName(address);
							String nextDuedate=getPersonRS.getString("nextDuedate") !=null ?getPersonRS.getString("nextDuedate"):"Not Pending";
							
							maintBean.setFromMonth(nextDuedate);
							//maintBean.setPendingAmount(getPersonRS.getString("pendingAmount")!=null?getPersonRS.getString("pendingAmount"):"0");
							maintBean.setNextDueDate(getPersonRS.getString("nextDuedate") !=null ?getPersonRS.getString("nextDuedate"):"Not Pending");
							System.out.println("pkString personame id "+personNameId);
							System.out.println("retrieve maintenance data");
							
						}while(getPersonRS.next());
					}
					
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		System.out.println("mysql driver is loaded");
		request.setAttribute("errorMessage", errorMessage);
		request.setAttribute("maintBean", maintBean);
		//RequestDispatcher rd= request.getRequestDispatcher("addSocietyPayment.jsp");
		RequestDispatcher rd= request.getRequestDispatcher("payMaintenance.jsp");
		rd.forward(request, response);
		
		//response.sendRedirect( "addSocietyPayment.jsp" );
		
		
	}
	

}
