package chs.maintModule;

public class MaintenanceBean {
	private String firstName;
	private String lastName;
	private String fullName;
	private String flatName;
	private String paymentmode;
	private String chequeNumber;
	private String chequeAmount;
	private String chequeAccountNumber;
	private String chequeBank;
	private String cashAmount;
	private String fromMonth;
	private String toMonth;
	private String nextDueDate;
	private String pendingAmount;
	private String MaintGivenTo;
	private String PersonNameId;
	private String maintenanceDefaulter;
	private String maintDefaulterFlag;
	private String overDueMonth;
	
	public String getOverDueMonth() {
		return overDueMonth;
	}
	public void setOverDueMonth(String overDueMonth) {
		this.overDueMonth = overDueMonth;
	}
	public String getMaintDefaulterFlag() {
		return maintDefaulterFlag;
	}
	public void setMaintDefaulterFlag(String maintDefaulterFlag) {
		this.maintDefaulterFlag = maintDefaulterFlag;
	}
	public String getMaintenanceDefaulter() {
		return maintenanceDefaulter;
	}
	public void setMaintenanceDefaulter(String maintenanceDefaulter) {
		this.maintenanceDefaulter = maintenanceDefaulter;
	}
	public String getPersonNameId() {
		return PersonNameId;
	}
	public void setPersonNameId(String personNameId) {
		PersonNameId = personNameId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getFlatName() {
		return flatName;
	}
	public void setFlatName(String flatName) {
		this.flatName = flatName;
	}
	public String getPaymentmode() {
		return paymentmode;
	}
	public void setPaymentmode(String paymentmode) {
		this.paymentmode = paymentmode;
	}
	public String getChequeNumber() {
		return chequeNumber;
	}
	public void setChequeNumber(String chequeNumber) {
		this.chequeNumber = chequeNumber;
	}
	public String getChequeAmount() {
		return chequeAmount;
	}
	public void setChequeAmount(String chequeAmount) {
		this.chequeAmount = chequeAmount;
	}
	public String getChequeAccountNumber() {
		return chequeAccountNumber;
	}
	public void setChequeAccountNumber(String chequeAccountNumber) {
		this.chequeAccountNumber = chequeAccountNumber;
	}
	public String getChequeBank() {
		return chequeBank;
	}
	public void setChequeBank(String chequeBank) {
		this.chequeBank = chequeBank;
	}
	public String getCashAmount() {
		return cashAmount;
	}
	public void setCashAmount(String cashAmount) {
		this.cashAmount = cashAmount;
	}
	public String getFromMonth() {
		return fromMonth;
	}
	public void setFromMonth(String fromMonth) {
		this.fromMonth = fromMonth;
	}
	public String getToMonth() {
		return toMonth;
	}
	public void setToMonth(String toMonth) {
		this.toMonth = toMonth;
	}
	public String getNextDueDate() {
		return nextDueDate;
	}
	public void setNextDueDate(String nextDueDate) {
		this.nextDueDate = nextDueDate;
	}
	public String getPendingAmount() {
		return pendingAmount;
	}
	public void setPendingAmount(String pendingAmount) {
		this.pendingAmount = pendingAmount;
	}
	public String getMaintGivenTo() {
		return MaintGivenTo;
	}
	public void setMaintGivenTo(String maintGivenTo) {
		MaintGivenTo = maintGivenTo;
	}
	

}
