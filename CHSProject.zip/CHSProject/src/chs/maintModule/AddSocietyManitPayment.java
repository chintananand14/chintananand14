package chs.maintModule;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AddSocietyManitPayment
 */
@WebServlet("/AddSocietyManitPayment")
public class AddSocietyManitPayment extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddSocietyManitPayment() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		String errMessage=null;
		String  succMessage=null;
		String pendingAmount=request.getParameter("pendingAmount");
		String personNameId=request.getParameter("personNameId");
		String address=request.getParameter("address");
		String wing=address.substring(0,1);
		System.out.println("wing ::"+wing);
		String flatNum=address.substring(1);
		System.out.println("flatNumb ::"+flatNum);
		String nextduedate=request.getParameter("nextduedate");
		String fromDate=request.getParameter("fromDate");
		String toDate=request.getParameter("toDate");
		String cheque=request.getParameter("cheque");
		String cash=request.getParameter("cash");
		String paymode=cheque !=null ?cheque :cash;
		String chequeNumber=request.getParameter("chequeNumber");
		String chequeAmount=request.getParameter("chequeAmount");
		String chequeBankName=request.getParameter("chequeBankName");
		String chequeBankNumber=request.getParameter("chequeBankNumber");
		String cashAmount=request.getParameter("cashAmount");
		//String chequeNumber=request.getParameter("chequeNumber");
		String maintGivenTo=request.getParameter("maintGivenTo");
		String amount=cashAmount!=null?cashAmount :chequeAmount;
		if(amount=="") {
			amount="0";
		}
		int amountInt=Integer.parseInt(amount);
		int pendingFromDB=Integer.parseInt(pendingAmount);
		int RemainingAmount=pendingFromDB-amountInt;
		int pendingAmountCal=0;
		if(RemainingAmount <=0) {
			RemainingAmount=pendingAmountCal;
		}
		
		System.out.println("pendingAmount :"+pendingAmount);
		System.out.println("personNameId "+personNameId);
		System.out.println("address :"+address);
		System.out.println("nextduedate :"+nextduedate);
		System.out.println("fromDate "+fromDate);
		System.out.println("toDate :"+toDate);
		System.out.println("cheque :"+cheque);
		System.out.println("cash :"+cash);
		System.out.println("chequeNumber :"+chequeNumber);
		System.out.println("chequeAmount :"+chequeAmount);
		System.out.println("chequeBankName :"+chequeBankName);
		System.out.println("chequeBankNumber :"+chequeBankNumber);
		System.out.println("cashAmount :"+cashAmount);
		System.out.println("maintGivenTo :"+maintGivenTo);
		java.util.Date todate1=null;
		java.sql.Date mytoDate =null;
		java.sql.Date nextDueDate=null;
		java.sql.Date myfromDate=null;
		java.util.Date fromdate1;
		String dueDt=null;
		try {
			fromdate1 = new SimpleDateFormat("dd/MM/yyyy").parse(fromDate);
			todate1 = new SimpleDateFormat("dd/MM/yyyy").parse(toDate);
			 myfromDate = new java.sql.Date(fromdate1.getTime());
			 mytoDate = new java.sql.Date(todate1.getTime());
			 //LAST_DAY("+mytoDate")
			 Calendar cal=Calendar.getInstance();
			 cal.setTime(mytoDate);
			 cal.add(Calendar.DAY_OF_YEAR,3);
			 SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			 dueDt= sdf.format(cal.getTime()); 
			 java.util.Date nextDueDate1=new SimpleDateFormat("dd/MM/yyyy").parse(dueDt);
			 nextDueDate=new java.sql.Date(nextDueDate1.getTime());
			// cal.getTime().getTime();
			 System.out.println("New seted due date String  "+dueDt);
			 System.out.println("New seted due date as Date  "+nextDueDate);
			// nextDueDate=myfromDate = new java.sql.Date(fromdate1.getTime());
			//System.out.println(""+cal.add(Calendar.DAY_OF_MONTH, -10));
			 //nextDueDate = nextDueDate. getDay() + 1  ;
			// System.out.println("nextDueDate ::"+nextDueDate);
			
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		String RemainingAmountStr= Integer.toString(RemainingAmount);
		//String maintGivenTo="System";
		//insert data to maintenece payment table
		
		String checkMaintRecord="select personnameId from maintenancepay where wing='"+wing+"' and FlatNumber='"+flatNum+"' and fromMonth='"+myfromDate+"' OR toMonth='"+mytoDate+"'";
		
		String insertMaintPaySql="INSERT INTO maintenancepay\r\n" + 
				"(personnameId,\r\n" + 
				"Wing,\r\n" + 
				"FlatNumber,\r\n" + 
				"paymentMode,\r\n" + 
				"chequeNumber,\r\n" + 
				"chequeAmount,\r\n" + 
				"chequeAccountNumber,\r\n" + 
				"chequeBank,\r\n" + 
				"cashAmount,\r\n" + 
				"fromMonth,\r\n" + 
				"toMonth,\r\n" + 
				"nextDuedate,\r\n" + 
				"pendingAmount,\r\n" + 
				"MaintGivenTo,lastupdatedt)\r\n" + 
				"VALUES\r\n" + 
				"('"+personNameId.trim()+"','"+wing+"','"+flatNum+"','"+paymode+"','"+chequeNumber+"','"+chequeAmount+"','"+chequeBankNumber+"','"+chequeBankName+"','"+cashAmount+"','"+myfromDate+"',LAST_DAY('"+mytoDate+"'),adddate(last_day('"+mytoDate+"'), 1),'"+RemainingAmountStr+"','"+maintGivenTo+"',now())";
		
		try {
			Class.forName("com.mysql.jdbc.Driver");  
			System.out.println("mysql driver is loaded");
			Connection con=DriverManager.getConnection(  
			"jdbc:mysql://localhost:3306/cshsdb","root","root");  
			System.out.println("connection established");
			//here sonoo is database name, root is username and password  
			Statement stmt=con.createStatement();  
			System.out.println("checkMaintRecord query "+checkMaintRecord);
			ResultSet checkMainRecordRS=stmt.executeQuery(checkMaintRecord);
			
			if(checkMainRecordRS.next()==false) {
				System.out.println("OK to insert record");
				stmt.execute(insertMaintPaySql);
				
			succMessage="Record inserted Successfully";
			}else {
				 errMessage="Record is not inserted  ";
				System.out.println("FromDate or ToDate mismatch with DB. Please check to view report");
			}
			//check existing record 
			
		}catch(SQLException e) {
			 errMessage="Record is not inserted  ";
			response.sendRedirect("addSocietyPayment.jsp?succMessage="+errMessage );
			e.printStackTrace();
			
		}catch(Exception e1) {
			e1.printStackTrace();
		}
		System.out.println("errMessage ::"+errMessage);
		System.out.println("succMessage ::"+succMessage);
		if(errMessage!=null) {
			response.sendRedirect( "MaintenanceHome.jsp?errorMessage="+errMessage );
		}else {
			response.sendRedirect( "MaintenanceHome.jsp?succMessage="+succMessage );
			
		}
		
		System.out.println("insertMaintPaySql -->"+insertMaintPaySql);
	}

}
