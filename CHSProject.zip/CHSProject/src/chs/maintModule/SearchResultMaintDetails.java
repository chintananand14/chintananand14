package chs.maintModule;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.StringUtils;

/**
 * Servlet implementation class SearchResultMaintDetails
 */
@WebServlet("/SearchResultMaintDetails")
public class SearchResultMaintDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchResultMaintDetails() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		String wing=request.getParameter("wing");
		String flatNum=request.getParameter("flatNum");
		String fromDate=request.getParameter("fromDate");
		String toDate=request.getParameter("toDate");
		String pendingAmountFromRange=request.getParameter("fromPendingAmt");
		String pendingAmountToRange=request.getParameter("toPendingAmt");
		String maintGivenDate=request.getParameter("maintGivenDate");
		String maintGivenTo=request.getParameter("maintGivenTo");
		String maintDefaulterFlag=request.getParameter("maintDefaulter");
		
		String addPaymentButton=request.getParameter("addPaymentButton");
		String searchButton=request.getParameter("SearchButton");
		System.out.println("addPaymentButton ::"+addPaymentButton);
		System.out.println("searchButton ::"+searchButton);
		MaintenanceBean maintBean= null;
		System.out.println("@@@@@");
		
		System.out.println("Wing ::"+wing+"flatNum:: "+flatNum+" fromDate ::  "+fromDate+" toDate ::"+toDate+"maintDefaulter ::"+maintDefaulterFlag);
		ArrayList <MaintenanceBean>searchMaintList=new ArrayList<MaintenanceBean>();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection(  
					"jdbc:mysql://localhost:3306/cshsdb","root","root");  
					System.out.println("connection established");
					//here sonoo is database name, root is username and password  
					Statement stmt=con.createStatement();  
					String flatName=wing.concat(flatNum);
					String personNameId=null;
					String fullName=null;
					String firstName=null;
					String lastName=null;
					String address=null;
					StringBuffer sbBuffer=new StringBuffer();
					//sbBuffer.append(dynamicSQl);
					String dynamicSQl="select FirstName ,LastName,mp.PersonNameId,wing,"
							//+ "flatNametpcd,"
							+ "pendingAmount,nextDuedate,fromMonth,toMonth,flatNumber,"
							+ "cashAmount,chequeAmount,paymentMode,chequeAccountNumber,chequeNumber,TIMESTAMPDIFF(MONTH, nextDuedate,current_date()) as overduewmonth"
							+ " from maintenancepay mp,persondetail pd where pd.PersonNameId=mp.personnameId and ";
					sbBuffer.append(dynamicSQl);
					System.out.println("wing ::"+wing);
					System.out.println("flatNum ::"+flatNum);
					if(!StringUtils.isNullOrEmpty(wing) && !StringUtils.isNullOrEmpty(flatNum)) {
						System.out.println("inside if loop");
						if("All".equalsIgnoreCase(wing)) {
							wing="'A','B','C','D','E'";
							sbBuffer.append("wing in ("+wing+") and flatNumber='"+flatNum+"' ");
							
						}else {
							sbBuffer.append("wing in ('"+wing+"') and flatNumber='"+flatNum+"' ");
						}
						//dynamicSQl.concat("wing ='"+wing+"' and flatNumber='"+flatNum+"'");
						
					}else if(!StringUtils.isNullOrEmpty(wing)) 
					{
						if("All".equalsIgnoreCase(wing)) {
							wing="'A','B','C','D','E'";
							sbBuffer.append(" wing in  ("+wing+") ");
							
						}else {
							sbBuffer.append(" wing in  ('"+wing+"') ");
						}
						if(maintDefaulterFlag.equalsIgnoreCase("Y")) {
							
							String defaulterSQl="select FirstName ,LastName,mp.PersonNameId,wing,"
									//+ "flatNametpcd,"
									+ "pendingAmount,nextDuedate,fromMonth,toMonth,flatNumber,"
									+ "cashAmount,chequeAmount,paymentMode,chequeAccountNumber,chequeNumber,TIMESTAMPDIFF(MONTH, nextDuedate,current_date()) as overduewmonth"
									+ " from maintenancepay mp,persondetail pd where pd.PersonNameId=mp.personnameId  ";
						}
						//dynamicSQl.concat("(wing ='"+wing+"' )");
						//sbBuffer.append(" wing in  ("+wing+") ");
					}
					if(!StringUtils.isNullOrEmpty(fromDate) || !StringUtils.isNullOrEmpty(toDate)) {
						
						if(!StringUtils.isNullOrEmpty(fromDate) && !StringUtils.isNullOrEmpty(toDate)) {
							sbBuffer.append("AND fromMonth >='"+fromDate+"' AND toMonth <='"+toDate+"' ");
						}else {
							sbBuffer.append("AND fromMonth >='"+fromDate+"' OR toMonth <='"+toDate+"' ");
						}
					}
					if(!StringUtils.isNullOrEmpty(pendingAmountFromRange) || !StringUtils.isNullOrEmpty(pendingAmountToRange)) {
						//dynamicSQl.concat("OR fromDate='"+fromDate+"'or todate='"+toDate+"'");
						//if(StringUtils.isNullOrEmpty(fromDate))
						if(!StringUtils.isNullOrEmpty(pendingAmountFromRange) && !StringUtils.isNullOrEmpty(pendingAmountToRange)) {
							sbBuffer.append("AND pendingAmount between '"+pendingAmountFromRange+"' and '"+pendingAmountToRange+"'");
						}else {
							sbBuffer.append("AND pendingAmount >='"+pendingAmountFromRange+"'or pendingAmount <='"+pendingAmountToRange+"' ");
						}
						
					}
					
					System.out.println("####@@@@");
					//System.out.println("dynamicSQl ::"+dynamicSQl);
					System.out.println("dynamicSQl ::"+sbBuffer.toString());
															 		
					ResultSet getPersonRS=stmt.executeQuery(sbBuffer.toString());
					if(getPersonRS.next()==false) {
						System.out.println("Primary Owner of this flat is not added .");
					}else {
						do { maintBean=new MaintenanceBean();
							personNameId=getPersonRS.getString("PersonNameId");
							firstName=getPersonRS.getString("FirstName");
							lastName=getPersonRS.getString("LastName");
							fullName=firstName.concat(" ").concat(lastName);
							String overduemonth=getPersonRS.getString("overduewmonth");
							if(Integer.parseInt(overduemonth)>=6) {
								maintBean.setOverDueMonth(overduemonth);
								maintBean.setMaintenanceDefaulter("Yes");
							}else {
								maintBean.setOverDueMonth(overduemonth);
								maintBean.setMaintenanceDefaulter("No");
							}
							
							//address=getPersonRS.getString("flatNametpcd");
							address=getPersonRS.getString("wing")+""+getPersonRS.getString("flatNumber");
							maintBean.setCashAmount(getPersonRS.getString("cashAmount"));
							maintBean.setFromMonth(getPersonRS.getString("fromMonth"));
							maintBean.setToMonth(getPersonRS.getString("toMonth"));
							maintBean.setChequeAmount(getPersonRS.getString("chequeAmount"));
							maintBean.setPaymentmode(getPersonRS.getString("paymentMode"));
							maintBean.setChequeAccountNumber(getPersonRS.getString("chequeAccountNumber"));
							maintBean.setChequeNumber(getPersonRS.getString("chequeNumber"));
							
							maintBean.setFullName(fullName);
							maintBean.setFirstName(firstName);
							maintBean.setLastName(lastName);
							maintBean.setPersonNameId(personNameId);
							maintBean.setFlatName(address);
							maintBean.setPendingAmount(getPersonRS.getString("pendingAmount")!=null?getPersonRS.getString("pendingAmount"):"0");
							maintBean.setNextDueDate(getPersonRS.getString("nextDuedate") !=null ?getPersonRS.getString("nextDuedate"):"Not Pending");
							maintBean.setMaintDefaulterFlag(maintDefaulterFlag);
							
							System.out.println("pkString personame id "+personNameId);
							System.out.println("retrieve maintenance data");
							searchMaintList.add(maintBean);
						}while(getPersonRS.next());
						
					}
					
					
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		System.out.println("mysql driver is loaded");
		System.out.println("arraylist maintainence search result size ::"+searchMaintList.size());
		request.setAttribute("searchMaintList", searchMaintList);
		request.setAttribute("maintDefaulterFlag", maintDefaulterFlag);
		RequestDispatcher rd= request.getRequestDispatcher("SearchMaintenanceReport.jsp");
		rd.forward(request, response);
		
	}

	}

