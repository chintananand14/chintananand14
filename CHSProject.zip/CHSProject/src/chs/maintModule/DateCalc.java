package chs.maintModule;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.mysql.jdbc.StringUtils;

public class DateCalc {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		java.util.Date todate1=null;
		java.sql.Date mytoDate =null;
		java.sql.Date nextDueDate=null;
		java.sql.Date myfromDate=null;
		java.util.Date fromdate1;
		String chintan="abcd";
		int a=15;
		if(a<0) {
			System.out.println("number is less than zero");
		}else {
			System.out.println("number is greater than zero");
		}
		String anand="";
		String fromDate="01/12/2017";
		String toDate="30/12/2017";
		String wing="'A','B','C','D','E'";
		System.out.println("wing "+wing);
		try {
			if(!StringUtils.isNullOrEmpty(chintan) && !StringUtils.isNullOrEmpty(anand) ) {
				System.out.println("true");
			}else {
				System.out.println("false");
			}
			fromdate1 = new SimpleDateFormat("dd/MM/yyyy").parse(fromDate);
			todate1 = new SimpleDateFormat("dd/MM/yyyy").parse(toDate);
			 myfromDate = new java.sql.Date(fromdate1.getTime());
			 mytoDate = new java.sql.Date(todate1.getTime());
			 mytoDate.getMonth();
			 mytoDate.getYear();
			 mytoDate.getDay();
			 Calendar cal=Calendar.getInstance();
			 cal.setTime(mytoDate);
			 cal.add(Calendar.DAY_OF_YEAR,3);
			 SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			String dueDt= sdf.format(cal.getTime()); 
			// cal.getTime().getTime();
			 System.out.println("New seted due date "+dueDt);
			 
			
			//System.out.println(""+cal.add(Calendar.DAY_OF_MONTH, -10));
			 //nextDueDate = nextDueDate. getDay() + 1  ;
			 System.out.println("nextDueDate ::"+nextDueDate);
			 
			 String date = "13/02/2012";
			 SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
			// Date convertedDate = dateFormat.parse(todate1);
			 Calendar c = Calendar.getInstance();
			 c.setTime(todate1);
			 
			
			 Date d=c.getTime();
			 
			 
			
				String lastDt= sdf.format(c.getTime()); 
				System.out.println("last date of month ::"+d);
			 
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
