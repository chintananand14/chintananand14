package chs.userModule;

public class PersonBean {
	private String personNameId;
	private String FirstName;
	private String LastName;
	private String gender;
	private String ownerOrMember;
	private String flatnametpcd;
	private String societyName;
	private String idType;
	private String idNumber;
	private String fullName;
	
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getPersonNameId() {
		return personNameId;
	}
	public void setPersonNameId(String personNameId) {
		this.personNameId = personNameId;
	}
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getOwnerOrMember() {
		return ownerOrMember;
	}
	public void setOwnerOrMember(String ownerOrMember) {
		this.ownerOrMember = ownerOrMember;
	}
	public String getFlatnametpcd() {
		return flatnametpcd;
	}
	public void setFlatnametpcd(String flatnametpcd) {
		this.flatnametpcd = flatnametpcd;
	}
	public String getSocietyName() {
		return societyName;
	}
	public void setSocietyName(String societyName) {
		this.societyName = societyName;
	}
	public String getIdType() {
		return idType;
	}
	public void setIdType(String idType) {
		this.idType = idType;
	}
	public String getIdNumber() {
		return idNumber;
	}
	public void setIdNumber(String idNumber) {
		this.idNumber = idNumber;
	}
	

}
