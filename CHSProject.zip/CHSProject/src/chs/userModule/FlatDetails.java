/**
 * 
 */
package chs.userModule;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashSet;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author admin
 *
 */
public class FlatDetails extends HttpServlet{
	 public void doPost(HttpServletRequest request, HttpServletResponse response)
             throws IOException, ServletException {
		 System.out.println("inside servlet");
		
		 String errorMessage=null;
		 boolean passValidation =true;
		 StringBuffer errorMessageSB=new StringBuffer();
		 boolean  succPersonalDeString=false;
		 String OwnerOrMember= request.getParameter("OwnerOrMember");
		
		String fname=request.getParameter("fname");
		String mname=request.getParameter("mname");
		String lname=request.getParameter("lname");
		String dob=request.getParameter("dob");
		
		System.out.println("fname ::"+fname);
		System.out.println("mname ::"+mname);
		System.out.println("lname ::"+lname);
		System.out.println("dob ::"+dob);
		System.out.println("OwnerOrMember ::"+OwnerOrMember);
		
		String gender=request.getParameter("gender");
		String isCommMem=request.getParameter("isCommMem");
		String yesCommitteeMemberDesg=request.getParameter("yesCommitteeMemberDesg");
		String mStatus=request.getParameter("mStatus");
			
		
		System.out.println("gender ::"+gender);
		System.out.println("isCommMem ::"+isCommMem);
		System.out.println("yesCommitteeMemberDesg ::"+yesCommitteeMemberDesg);
		System.out.println("mStatus ::"+mStatus);
		
		
		String wing=request.getParameter("wing");
		String flatNum=request.getParameter("flatNum");
		String flatTp=request.getParameter("flatTp");
		String flatArea=request.getParameter("flatArea");
		
		
		System.out.println("wing ::"+wing);
		System.out.println("flatNum ::"+flatNum);
		System.out.println("flatTp ::"+flatTp);
		System.out.println("flatArea ::"+flatArea);
		
		boolean notinsertPersondetailFlag=false;
		String identificationType=request.getParameter("identificationType");
		String identificationNum=request.getParameter("identificationNum");
		String mobileNum=request.getParameter("mobileNum");
		String emailId=request.getParameter("emailId");
		
		System.out.println("identificationType ::"+identificationType);
		System.out.println("identificationNum ::"+identificationNum);
		System.out.println("mobileNum ::"+mobileNum);
		System.out.println("emailId ::"+emailId);
		
			
		String addressPfTp=request.getParameter("addressPfTp");
		String addressIdNum=request.getParameter("addressIdNum");
		String idHardCopySub=request.getParameter("idHardCopySub");
		
			
		System.out.println("addressPfTp ::"+addressPfTp);
		System.out.println("addressIdNum ::"+addressIdNum);
		System.out.println("idHardCopySub ::"+idHardCopySub);
		
		String pkString=generatePK( wing, flatNum, fname, lname,OwnerOrMember);
		String pepStatus="N";
		
		try {
		Class.forName("com.mysql.jdbc.Driver");  
		System.out.println("mysql driver is loaded");
		Connection con=DriverManager.getConnection(  
		"jdbc:mysql://localhost:3306/cshsdb","root","root");  
		System.out.println("connection established");
		//here sonoo is database name, root is username and password  
		Statement stmt=con.createStatement();  
		//System.out.println("Statement created"+queryString);
		
		//check existing record
		boolean addPersonalDetailFlag=false;
		boolean succInsertPeronId=false;
		boolean addIdentifierFlag=false;
		boolean addPersonAddressFlag=false;
		boolean addAddressByOwnerFlag=false;
		String nameEmptyFlag="";
		String customerIdEmptyFlag="";
		boolean duplicateCustomer=false;
		boolean insertRecord=false;
		String addessrecordFlag="";
		String identifierFlag="";
		String nameFlag="";
		String ownerOrMemberFlag="";
		boolean existOwnerOrMember=false;
		boolean existFlatNameCustomer=false;
		String ownerormemberEmptyFlag="";
		boolean existIdCustomer=false;
		boolean existNameCustomer=false;
		String flatname=wing.concat(flatNum);
		//********************getOwnerByIdentification*****************
		HashSet ownerByIdDB=new HashSet();
		HashSet ownerByotherIdDB=new HashSet();
		String ownerByIdStr=getOwnerById(identificationNum,identificationType);
		ResultSet ownerByIdStrRs=stmt.executeQuery(ownerByIdStr);
		
		if (ownerByIdStrRs.next() == false) 
		{ System.out.println("IdentifierRS is empty "); 
		System.out.println("Insert identifier ");
		addIdentifierFlag=true;
		  
		} else 
		{ do 
		{ System.out.println("inside identifier do while loop");
			String personnameidDB=ownerByIdStrRs.getString("personnameid");
			String firstnameDB=ownerByIdStrRs.getString("firstname");
			String lastnameDB=ownerByIdStrRs.getString("lastname");
			String genderDB=ownerByIdStrRs.getString("gender");
			String ownerormemberDB=ownerByIdStrRs.getString("ownerormember");
			String flatnametpcdDB=ownerByIdStrRs.getString("flatnametpcd");
			String societynameDB=ownerByIdStrRs.getString("societyname");
			String idnumberDB=ownerByIdStrRs.getString("idnumber");
			ownerByotherIdDB.add(firstnameDB.concat("-").concat(lastnameDB).concat("-").concat(idnumberDB));
			ownerByIdDB.add(flatnametpcdDB.concat("-").concat(firstnameDB).concat("-").concat(lastnameDB).concat("-").concat(idnumberDB)); 
		} while (ownerByIdStrRs.next()); 
		} 

		
		
		
		
		
		//**************************************************************
		
		
		//****************************getOwnerByAddress*********************//
		
		String ownerbyAddressStr=getOwnerByAddress(flatname);
		String addressByownerStr=getAddressByOwner(fname, lname);
		HashSet	AddressFlatDBSet = new HashSet();
		HashSet	IdFlatAddrDBSet = new HashSet();
		ResultSet ownerbyAddressRs=stmt.executeQuery(ownerbyAddressStr);
		
		System.out.println("ownerbyAddressStr query -->"+ownerbyAddressStr);
		
		if (ownerbyAddressRs.next() == false) 
		{ System.out.println("ownerbyAddressRs is empty "); 
		 System.out.println("Insert address for the flat owner");
		 addPersonAddressFlag=true;
		} else 
		{ do 
		{ System.out.println("inside ownerbyAddressRs do while loop");
			String personnameidDB=ownerbyAddressRs.getString("personnameid");
			String firstnameDB=ownerbyAddressRs.getString("firstname");
			String lastnameDB=ownerbyAddressRs.getString("lastname");
			String genderDB=ownerbyAddressRs.getString("gender");
			String ownerormemberDB=ownerbyAddressRs.getString("ownerormember");
			String flatnametpcdDB=ownerbyAddressRs.getString("flatnametpcd");
			String societynameDB=ownerbyAddressRs.getString("societyname");
			String idnumberDB=ownerbyAddressRs.getString("idnumber");
			System.out.println("ownerbyAddressRs ######");
			System.out.println("personnameidDB -->"+personnameidDB);
			System.out.println("firstnameDB -->"+firstnameDB);
			System.out.println("lastnameDB -->"+lastnameDB);
			System.out.println("genderDB -->"+genderDB);
			System.out.println("ownerormemberDB -->"+ownerormemberDB);
			System.out.println("flatnametpcdDB -->"+flatnametpcdDB);
			System.out.println("societynameDB -->"+societynameDB);
			System.out.println("idnumberDB -->"+idnumberDB);
		
			//AddressFlatDBSet.add(flatnametpcdDB.concat("-").concat(firstnameDB).concat("-").concat(lastnameDB).concat("-").concat(ownerormemberDB));
			AddressFlatDBSet.add(flatnametpcdDB.concat("-").concat(ownerormemberDB).concat("-").concat(firstnameDB).concat("-").concat(lastnameDB));
			//IdFlatAddrDBSet.add(flatnametpcdDB.concat("-").concat(firstnameDB).concat("-").concat(lastnameDB).concat("-").concat(idnumberDB));
			System.out.println("ownerbyAddressRs @@@@@");
			
		} while (ownerbyAddressRs.next()); 
		}
		
		
		boolean succInsertAddrQry=false;
		
		HashSet ownerFlatDBSet=new HashSet<String>();
		HashSet ownerIdFlatDBSet=new HashSet<String>();
		HashSet ownerFlatInputSet=new HashSet<String>();
		HashSet addressFlatInputSet=new HashSet<String>();
		HashSet ownerFlatInputSetTest=new HashSet<String>();
		HashSet ownerIdFlatInputSet=new HashSet<String>();
		String OwnerOrMembertoTest="";
		if("FPO".equalsIgnoreCase(OwnerOrMember)) {
			OwnerOrMembertoTest="FM";
			ownerFlatInputSetTest.add(flatname.concat("-").concat(fname).concat("-").concat(lname).concat("-").concat(OwnerOrMembertoTest));
		}else {
			OwnerOrMembertoTest="FPO";
			ownerFlatInputSetTest.add(flatname.concat("-").concat(fname).concat("-").concat(lname).concat("-").concat(OwnerOrMembertoTest));
		}
		ownerIdFlatInputSet.add(flatname.concat("-").concat(fname).concat("-").concat(lname).concat("-").concat(identificationNum));
		ownerFlatInputSet.add(flatname.concat("-").concat(fname).concat("-").concat(lname).concat("-").concat(OwnerOrMember));
		addressFlatInputSet.add(flatname.concat("-").concat(OwnerOrMember));
		ResultSet addressByownerRs=stmt.executeQuery(addressByownerStr);
		
		if (addressByownerRs.next() == false) 
		{ 
			System.out.println("addressByownerRs is empty "); 
			System.out.println("insert address for owner ");
			addAddressByOwnerFlag=true;
		} else 
		{ do 
		{ System.out.println("inside addressByownerRs do while loop");
			String personnameidDB=addressByownerRs.getString("personnameid");
			String firstnameDB=addressByownerRs.getString("firstname");
			String lastnameDB=addressByownerRs.getString("lastname");
			String genderDB=addressByownerRs.getString("gender");
			String ownerormemberDB=addressByownerRs.getString("ownerormember");
			String flatnametpcdDB=addressByownerRs.getString("flatnametpcd");
			String societynameDB=addressByownerRs.getString("societyname");
			String idnumberDB=addressByownerRs.getString("idnumber");
			ownerFlatDBSet.add(flatnametpcdDB.concat("-").concat(firstnameDB).concat("-").concat(lastnameDB).concat("-").concat(ownerormemberDB));
			ownerIdFlatDBSet.add(flatnametpcdDB.concat("-").concat(firstnameDB).concat("-").concat(lastnameDB).concat("-").concat(idnumberDB));
			System.out.println("personnameidDB -->"+personnameidDB);
			System.out.println("firstnameDB -->"+firstnameDB);
			System.out.println("lastnameDB -->"+lastnameDB);
			System.out.println("genderDB -->"+genderDB);
			System.out.println("ownerormemberDB -->"+ownerormemberDB);
			System.out.println("flatnametpcdDB -->"+flatnametpcdDB);
			System.out.println("societynameDB -->"+societynameDB);
			System.out.println("idnumberDB -->"+idnumberDB);
				} while (addressByownerRs.next()); 
		}
		
			
		
		//Comparing two Sets
		boolean recordExist=ownerFlatDBSet.containsAll(ownerFlatInputSet);
		System.out.println("ownerFlatInputSet elements ::");
				
		Iterator setIterator = ownerFlatInputSet.iterator();
				while(setIterator.hasNext()){
				   String item = (String)setIterator.next();
				   System.out.println("Elements  ownerFlatInputSet::"+item);
				  
				}
				
				Iterator setIterator1 = ownerFlatDBSet.iterator();
				while(setIterator1.hasNext()){
				   String item = (String)setIterator1.next();
				   System.out.println("Elements  ownerFlatDBSet::"+item);
				  
				}
				
				int matchcount=0;
				int unmatchCount=0;
				Iterator setIterator2 = ownerByotherIdDB.iterator();
				while(setIterator2.hasNext()){
				   String item = (String)setIterator2.next();
				   String[] myItem=item.split("-");
				  String abc= myItem[0];
				  String abc1= myItem[1];
				  String abc2= myItem[2];
				  
				  if(identificationNum.equalsIgnoreCase(abc2))
					{
					  if(abc.equalsIgnoreCase(fname) && abc1.equalsIgnoreCase(lname)) {
						  System.out.println("id is mapped correctly to the same user"+fname);
						  matchcount++;
					  }else {
						  System.out.println("id is mapped already to different user");
						  unmatchCount++;
					  }
					  
		    	  }else {
		    		  System.out.println("id does not exist");
		    		  
		    	  }
				  
				  }
				if(matchcount==0 && unmatchCount==0) {
					  System.out.println("ID doesnot exist &&&");
				  }else if(matchcount==1 && unmatchCount==0) {
					  System.out.println("ID mapped to same user  &&&"); 
					  succInsertPeronId=true;
				  }else if(matchcount==0 && unmatchCount>0) {
				   System.out.println("id match with different user::");
				   passValidation=false;
				  // succInsertPeronId=false;
				   errorMessageSB= errorMessageSB.append("id Belongs to the different user \n");
				  }else if(matchcount >0 && unmatchCount>0) {
					  System.out.println("id mapped to the same user as well as  different user::");  
					  errorMessageSB= errorMessageSB.append("id mapped to the two different user\n");
					  passValidation=false;
					  //succInsertPeronId=false;
				  }
				  



				//Read more: http://javarevisited.blogspot.com/2012/06/hashset-in-java-10-examples-programs.html#ixzz52gpIEDy0
					
		if(recordExist) {
			System.out.println("person detail record already exist");
			succPersonalDeString=true;
			errorMessageSB=errorMessageSB.append("person detail record already exist \n");
			passValidation=false;
			
			
		}else
		{
			//System.out.println("record does not exist");
			
			
			boolean recordExistTest= ownerFlatDBSet.containsAll(ownerFlatInputSetTest);
			if(recordExistTest) {
				System.out.println("Same user can not be add as primary FM/FM for"+fname+" "+lname);
				errorMessageSB=errorMessageSB.append("Same user can not be add as primary FM/FM for"+fname+" "+lname+"\n");
				passValidation=false;
				
			}else {
								
				 recordExist=AddressFlatDBSet.containsAll(addressFlatInputSet);
				System.out.println("AddressFlatDBSet elements ::");
				if(AddressFlatDBSet.isEmpty())
				{
					//c5 is not in DB
					if("FM".equalsIgnoreCase(OwnerOrMember)) {
						passValidation=false;
						System.out.println("for flat name there is not PFO is added"+flatname);
						errorMessageSB=errorMessageSB.append("for flat name "+flatname+" PFO is not added \n");
					}else {
						System.out.println("for flat name there is not PFO is added"+flatname);
						passValidation=true;
					}
					
				}else {
					setIterator1 = AddressFlatDBSet.iterator();
					
					while(setIterator1.hasNext()){
					   String item = (String)setIterator1.next();
					   System.out.println("address details in loop items ::"+item);
					   String[] flatOwner=item.split("-");
					   String flatNameDB=flatOwner[0];
					   String memownerDB=flatOwner[1];
					   String fnameDB=flatOwner[2];
					   String lnameDB=flatOwner[3];
					   
					   if("FPO".equalsIgnoreCase(memownerDB) && flatname.equalsIgnoreCase(flatNameDB)) {
						   if(fname.equalsIgnoreCase(fnameDB) && lname.equalsIgnoreCase(lnameDB) && "FPO".equalsIgnoreCase(OwnerOrMember)) {
							   System.out.println("same record exists 111");
							   passValidation=true;
						   }
						   else if("FPO".equalsIgnoreCase(OwnerOrMember)&& (!fname.equalsIgnoreCase(fnameDB) || !lname.equalsIgnoreCase(lnameDB))) {
							   System.out.println("Flat Primary Owner already exists for this flat 111");
							   passValidation=false;
							   
						   }
						   else if(!"FPO".equalsIgnoreCase(OwnerOrMember)&& (!fname.equalsIgnoreCase(fnameDB) || !lname.equalsIgnoreCase(lnameDB))) {
							   System.out.println("Flat member ok to insert 111");
							   passValidation=true;
						   }
					   }else if(!"FPO".equalsIgnoreCase(memownerDB) && flatname.equalsIgnoreCase(flatNameDB)) {
						   
						   if(fname.equalsIgnoreCase(fnameDB) && lname.equalsIgnoreCase(lnameDB) && "FPO".equalsIgnoreCase(OwnerOrMember)) {
							   System.out.println("Same member can not become FPO 111");
							   passValidation=false;
						   }else if((!fname.equalsIgnoreCase(fnameDB) || !lname.equalsIgnoreCase(lnameDB)) && "FPO".equalsIgnoreCase(OwnerOrMember)) {
							   System.out.println("its ok to insert 111"); 
							   passValidation=true;
						   }
					   }
					   
					    System.out.println("Elements  AddressFlatDBSet::"+item);
					  
				}
					
				}
				
				
			}
			
		}
		

		//boolean addPersonalDetailFlag=false;
		//boolean addIdentifierFlag=false;
		//boolean addPersonAddressFlag=false;
		//boolean addAddressByOwnerFlag=false;
		if(!passValidation) {
			System.out.println("There is some issues in Data");
			System.out.println("in pass validation false logic");
		}
		if(passValidation) {
			System.out.println("in pass validation true logic");
			int succPersonSuccCount=0;
			
				String getPersonString="select PersonNameId from PersonDetail where FirstName='"+fname+"' and LastName = '"+lname+"'";
				ResultSet getPersonRS=stmt.executeQuery(getPersonString);
				if(getPersonRS.next()==false) {
					System.out.println("new person record");
					String personDetailqueryString="insert into PersonDetail(PersonNameId,FirstName,MiddleName,LastName,Gender,MaritalStatusTpcd,SocCommMembTpCd,ownerOrMember)"
							+ " values('"+pkString+"','"+fname+"','"+mname+"','"+lname+"','"+gender+"','"+mStatus+"','"+isCommMem+"','"+OwnerOrMember+"')";	
					
					System.out.println("queryString :::"+personDetailqueryString);
					
					succPersonSuccCount=stmt.executeUpdate(personDetailqueryString);
					 System.out.println("succPersonalDeString after insert "+succPersonSuccCount);
					if(succPersonSuccCount >0) {
						System.out.println("personal detail is inserted");
						succPersonalDeString=true;
						
					}
				
					
				}else {
					do { 
						pkString=getPersonRS.getString("PersonNameId");
						System.out.println("pkString personame id "+pkString);
						System.out.println("personal detail is already inserted");
						
					}while(getPersonRS.next());
				}
					
				
				String getPerIdString="select PerIdentificationId from  PerIdentification where identificationNumber='"+identificationNum+"'";
				ResultSet  getPerIdRS=stmt.executeQuery(getPerIdString);
				if(getPerIdRS.next()==false) {
					System.out.println("New identification record ");
					String PerIdentificationId=pkString+identificationType+identificationNum;
					String queryIdentString="insert into PerIdentification(PerIdentificationId,PersonNameId,identificationType,identificationNumber) "
							+ "values('"+PerIdentificationId+"','"+pkString+"','"+identificationType+"','"+identificationNum+"')";
					System.out.println("queryIdentString identification ->"+queryIdentString);
					int  succIdentString=stmt.executeUpdate(queryIdentString);
					if(succIdentString >0)
					{
						System.out.println("successfully inserted into PerIdentification");
						succInsertPeronId=true;
					
					
				}
				
				}else {
					do {
						System.out.println("identification already exists");
					String PerIdentificationId=	getPerIdRS.getString("PerIdentificationId");
					System.out.println("PerIdentificationId -->"+PerIdentificationId);
						
					}while(getPerIdRS.next());
					
				}
					String addressIdPk=null;
				//insert into person address and address
				String addressQueryString="select addressId from address where flatNametpcd='"+flatname+"'";
				ResultSet addressQueryRS=stmt.executeQuery(addressQueryString);
				if (addressQueryRS.next() == false) 
				{ 
					System.out.println("new address . address does not exist "); 
					
					
					String societyName="CSHS";
					String insertAddressQuery="insert into address (addressId,flatNametpcd,societyName) values ('"+flatname+"','"+flatname+"','"+societyName+"')";
					int succInsrtAddrCount=stmt.executeUpdate(insertAddressQuery);
					if(succInsrtAddrCount >0)
					{
						succInsertAddrQry=true;
						System.out.println("successfully inserted into address");
						
						
						String addressQuerytring1="select addressId from address where flatNametpcd='"+flatname+"'";
						ResultSet addressQueryRS1=stmt.executeQuery(addressQueryString);
						
						
						
						if(addressQueryRS1.next()) {
							addressIdPk=addressQueryRS1.getString("addressId");
							
						}
						
					}
					addAddressByOwnerFlag=true;
				} else 
				{ do 
				{ System.out.println("inside addressQueryRS do while loop");
					 addressIdPk=addressQueryRS.getString("addressId");
					} while (addressQueryRS.next()); 
				}
												
				System.out.println("addressIdPk ::"+addressIdPk);
				//insert into personaddr table
				String personAddrPK=pkString+addressIdPk;
				
				boolean succInsertPersonAddrQry=false;
				
					String getpersonAddrStr="select PersonAddressId from personaddress where AddressId='"+addressIdPk+"' and personNameId='"+pkString+"' and flatNametpCd='"+flatname+"'";
					
					
					ResultSet getpersonAddrStrRs=stmt.executeQuery(getpersonAddrStr);
					if (getpersonAddrStrRs.next() == false) 
					{
						System.out.println("person address table new entry");
						String insertPersonAddrQry="insert into personaddress (PersonAddressId,personNameId,AddressId,flatNametpCd) values ('"+personAddrPK+"','"+pkString+"','"+addressIdPk+"','"+flatname+"')";
						
						int  succInsertPersonAddr=stmt.executeUpdate(insertPersonAddrQry);
						if(succInsertPersonAddr > 0)
						{
							succInsertPersonAddrQry=true;
							System.out.println("Successfully inserted into personaddress for personAddrPK "+personAddrPK);
							
						
						}
					} else 
					{ do 
					{ System.out.println("person address exist ");
						 addressIdPk=getpersonAddrStrRs.getString("PersonAddressId");
						} while (getpersonAddrStrRs.next()); 
					}
					
				
		  
		con.close();  
		}
		}
		catch(Exception e)
		{ System.out.println(e);
		}  
		System.out.println("Error Message -->"+errorMessageSB.toString());
		if(!passValidation) {
			errorMessageSB=errorMessageSB.append("there is some issues in data");
			response.sendRedirect( "FlatOwner.jsp?errorMessage="+errorMessageSB.toString() );
		}else {
			String succMessage="Record is inserted successfully ";
			response.sendRedirect( "FlatOwner.jsp?succMessage="+succMessage );
		}
			
		}  
	 
	  String  generatePK(String wing,String flatNum,String fname,String lname,String OwnerOrMember)
	 {
		  StringBuffer primaryKeyStr=new StringBuffer();
		  primaryKeyStr.append("CSHS").append(OwnerOrMember).append(wing).append(flatNum).append(lname).append(fname);
		  return primaryKeyStr.toString().trim();
		 
	 }
		
	  String  isRecordExist(String wing,String flatNum,String fname,String lname,String OwnerOrMember,String gender, String societyname, String idnumber)
	  
		 {
		  //first name
		  //last name
		  //Dob
		  //gender
		  //address
		  //identification
		  //societyName
		  String recordExistStr="select personnameid,firstname,lastname,gender,ownerormember,addressId,flatnametpcd,societyname,idtype,idnumber "
		  		+ "from peraddrview where "
		  		+ "firstname='"+fname+"' or lastname='"+lname+"' or gender='"+gender+"' or ownerormember='"+OwnerOrMember+"' or flatnametpcd='"+flatNum+"' or societyname='"+societyname+"' or idnumber='"+idnumber+"'";
		  
			 return recordExistStr;
			 
		 }
	  
	  String getOwnerByAddress(String flatname) {
		  String societyname="";
		  
		  String OwnerByAddressStr="select personnameid,firstname,lastname,gender,ownerormember,addressId,flatnametpcd,societyname,idtype,idnumber "
			  		+ "from peraddrview where "
			  		+ " flatnametpcd='"+flatname+"' or societyname='"+societyname+"' ";
			  
				 return OwnerByAddressStr;
		  }
	  
	  String getAddressByOwner(String fname,String lname) {
		  String societyname="";
		  
		  String addressByOwnerStr="select personnameid,firstname,lastname,gender,ownerormember,addressId,flatnametpcd,societyname,idtype,idnumber "
			  		+ "from peraddrview where "
			  		+ "firstname='"+fname+"' and lastname='"+lname+"'";
			  
				 return addressByOwnerStr;
			  
				 
		  }
	  String getOwnerById(String identificationNum,String identificationType) {
		  String ownerByIdStr="select personnameid,firstname,lastname,gender,ownerormember,addressId,flatnametpcd,societyname,idtype,idnumber "
			  		+ "from peraddrview where "
			  		+ " idnumber='"+identificationNum+"'";
			  
				 return ownerByIdStr;
				
		  
		  
	  }
	 }


