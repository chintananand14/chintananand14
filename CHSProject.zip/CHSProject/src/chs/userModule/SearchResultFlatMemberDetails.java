package chs.userModule;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.StringUtils;



/**
 * Servlet implementation class SearchResultFlatMemberDetails
 */
@WebServlet("/SearchResultFlatMemberDetails")
public class SearchResultFlatMemberDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchResultFlatMemberDetails() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		 String OwnerOrMember= request.getParameter("OwnerOrMember");
		String fname=request.getParameter("fname");
		String mname=request.getParameter("mname");
		String lname=request.getParameter("lname");
		String dob=request.getParameter("dob");
		
		System.out.println("fname ::"+fname);
		System.out.println("mname ::"+mname);
		System.out.println("lname ::"+lname);
		System.out.println("dob ::"+dob);
		System.out.println("OwnerOrMember ::"+OwnerOrMember);
		
		
		String isCommMem=request.getParameter("isCommMem");
		String yesCommitteeMemberDesg=request.getParameter("yesCommitteeMemberDesg");
		String mStatus=request.getParameter("mStatus");
			
		
		
		System.out.println("isCommMem ::"+isCommMem);
		System.out.println("yesCommitteeMemberDesg ::"+yesCommitteeMemberDesg);
		System.out.println("mStatus ::"+mStatus);
		
		
		String wing=request.getParameter("wing");
		String flatNum=request.getParameter("flatNum");
		String flatname=wing.concat(flatNum);
		
		System.out.println("wing ::"+wing);
		System.out.println("flatNum ::"+flatNum);
		StringBuffer sbBuffer=new StringBuffer();
		try {
			Class.forName("com.mysql.jdbc.Driver");  
			System.out.println("mysql driver is loaded");
			Connection con=DriverManager.getConnection(  
			"jdbc:mysql://localhost:3306/cshsdb","root","root");  
			System.out.println("connection established");
			//here sonoo is database name, root is username and password  
			Statement stmt=con.createStatement();  
			
			String dynamicSQl="select personNameId,FirstName,LastName,gender,ownerOrMember,flatnametpcd,"
					+ "societyName,idType,idNumber from peraddrview where ";
			
							
			sbBuffer.append(dynamicSQl);
			if(!StringUtils.isNullOrEmpty(wing) && !StringUtils.isNullOrEmpty(flatNum)) {
				System.out.println("inside if loop");
					sbBuffer.append(" flatnametpcd='"+flatname+"' ");
				
				//dynamicSQl.concat("wing ='"+wing+"' and flatNumber='"+flatNum+"'");
				
			}else if(!StringUtils.isNullOrEmpty(wing)) 
			{
					sbBuffer.append(" flatnametpcd like '%"+wing+"%' ");
				
			}else if(!StringUtils.isNullOrEmpty(fname) || !StringUtils.isNullOrEmpty(lname)) {
				
				if(!StringUtils.isNullOrEmpty(fname) && !StringUtils.isNullOrEmpty(lname)) {
					sbBuffer.append(" FirstName='"+fname+"' AND LastName='"+lname+"' ");
				}else {
					sbBuffer.append(" FirstName='"+fname+"' OR LastName='"+lname+"' ");
				}
			}
			System.out.println("Query personSearch ::"+sbBuffer.toString());
			ResultSet getPersonRS=stmt.executeQuery(sbBuffer.toString());
			
			String flatName=wing.concat(flatNum);
			String personNameId=null;
			String fullName=null;
			String firstName=null;
			String lastName=null;
			String address=null;
			//ArrayList <MaintenanceBean>searchMaintList=new ArrayList<MaintenanceBean>();
			
			ArrayList <PersonBean>searchPersonList=new ArrayList<PersonBean>();
			if(getPersonRS.next()==false) {
				System.out.println("Primary Owner of this flat is not added .");
			}else {
				do { PersonBean personBean=new PersonBean();
					personNameId=getPersonRS.getString("PersonNameId");
					firstName=getPersonRS.getString("FirstName");
					lastName=getPersonRS.getString("LastName");
					fullName=firstName.concat(" ").concat(lastName);
					String gender=getPersonRS.getString("gender");
					String ownerOrMember=getPersonRS.getString("ownerOrMember");
					String flatnametpcd=getPersonRS.getString("flatnametpcd");
					String societyName=getPersonRS.getString("societyName");
					String idType=getPersonRS.getString("idType");
					String idNumber=getPersonRS.getString("idNumber");
					personBean.setOwnerOrMember(ownerOrMember);
					personBean.setSocietyName(societyName);
					personBean.setIdType(idType);
					personBean.setIdNumber(idNumber);
					personBean.setFullName(fullName);
					personBean.setFirstName(firstName);
					personBean.setLastName(lastName);
					personBean.setPersonNameId(personNameId);
					personBean.setFlatnametpcd(flatnametpcd);
					personBean.setGender(gender);
					
					//maintBean.setMaintDefaulterFlag(maintDefaulterFlag);
					
					System.out.println("pkString personame id "+personNameId);
								
					System.out.println("retrieve maintenance data");
					searchPersonList.add(personBean);
				}while(getPersonRS.next());
				
			}
			
			System.out.println("arraylist maintainence search result size ::"+searchPersonList.size());
			request.setAttribute("searchPersonList", searchPersonList);
			//request.setAttribute("maintDefaulterFlag", maintDefaulterFlag);
			RequestDispatcher rd= request.getRequestDispatcher("SearchFlatMember.jsp");
			rd.forward(request, response);
			
			
		}catch(Exception e)
		{ System.out.println(e);
		}  
	
		
	}

}
